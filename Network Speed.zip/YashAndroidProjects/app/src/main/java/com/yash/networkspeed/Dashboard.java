package com.yash.networkspeed;

import android.app.Notification;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class Dashboard extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard);

    }
    public void showNotification(View v){
        Notification notification=new NotificationCompat.Builder()
                    .setContentTitle("New Notification");

    }
}
